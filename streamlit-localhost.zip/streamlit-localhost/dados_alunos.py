import streamlit as st
import pandas as pd
import altair as alt

# Configurações da página
st.set_page_config(page_title="Projeto Extensor - Escola da Nuvem", page_icon="img/logo.png", layout="wide")

# Função para carregar os dados
def load_data():
    df = pd.read_excel('alunos_pii_none.xlsx')
    return df

# Função para agrupar os dados semelhantes
def group_similar_categories(df):
    similar_groups = {
        'Pós graduação': ['Pós graduação', 'MBA', 'Mestrado', 'Pós-graduação'],
        'Ensino Superior': ['Superior Completo', 'Graduação'],
        'Ensino Médio': ['Ensino Médio Completo'],
        'Ensino Fundamental': ['Ensino Fundamental Completo', 'Fundamental'],
        'Outros': ['Outro', 'Não Especificado']
    }
    for new_category, categories in similar_groups.items():
        print(new_category)
        print(categories)
        df['Escolaridade'] = df['Escolaridade'].replace(categories, new_category)
    return df

# Função para plotar o gráfico de escolaridade com Altair
def plot_escolaridade(df):
    st.write("## Distribuição de alunos por nível de escolaridade")
    df = group_similar_categories(df)
    escolaridade_percentual = df['Escolaridade'].value_counts(normalize=True) * 100
    escolaridade_df = escolaridade_percentual.reset_index()
    escolaridade_df.columns = ['Escolaridade', 'Porcentagem']

    chart = alt.Chart(escolaridade_df).mark_bar().encode(
        x=alt.X('Escolaridade:N', sort='-y', title='Nível de Escolaridade'),
        y=alt.Y('Porcentagem:Q', title='Porcentagem (%)'),
        tooltip=[ 
            alt.Tooltip('Escolaridade:N', title='Escolaridade'),
            alt.Tooltip('Porcentagem:Q', format='.2f', title='Porcentagem (%)')
        ]
    ).properties(
        width=600,
        height=400,
        title='Distribuição por Nível de Escolaridade'
    )

    st.altair_chart(chart, use_container_width=True)

    escolaridade_df['Porcentagem'] = escolaridade_df['Porcentagem'].apply(lambda x: f"{x:.2f}%")
    st.write("Distribuição de níveis de escolaridade (%):")
    st.dataframe(escolaridade_df)

def intro():
    st.markdown('<h1 class="custom-title">Dados Escola da Nuvem</h1>', unsafe_allow_html=True)

    st.write("""
    Bem-vindo à análise dos dados da Escola da Nuvem!
    """)

    # Exibir o gráfico dentro de um expander minimizado
    with st.expander("📊 Ver preview da distribuição por escolaridade"):
        df = load_data()
        plot_escolaridade(df)

    # Adicionar o botão abaixo do expander
    if st.button("Ir para a página de Alunos"):
        # Quando o botão for pressionado, redireciona para a página "Alunos"
        st.session_state.page = "Alunos"
        st.experimental_rerun()  # Isso recarrega a página e muda para a página de Alunos

# Página principal de análise dos alunos
def alunos():
    st.markdown('<h1 class="custom-title">Dados Escola da Nuvem - Alunos</h1>', unsafe_allow_html=True)
    st.write("""
    Esta página apresenta uma análise dos dados dos alunos da Escola da Nuvem. 
    O objetivo é entender o perfil dos estudantes e gerar insights que ajudem a melhorar o impacto da iniciativa.
    """)

    df = load_data()
    plot_escolaridade(df)

# Mapeamento das páginas
page_names_to_funcs = {
    "—": intro,
    "Alunos": alunos
}

# Seleção da página
st.sidebar.image("img/logo.png", width=50, use_container_width=True)
st.sidebar.markdown("""
    **Bem-vindo ao Projeto Extensor**  
    Escolha uma visualização para explorar os dados dos alunos da Escola da Nuvem.
    """)
demo_name = st.sidebar.selectbox("Escolha uma visualização", page_names_to_funcs.keys())
page_names_to_funcs[demo_name]()