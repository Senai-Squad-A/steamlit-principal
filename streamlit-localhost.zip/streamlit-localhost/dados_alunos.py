import streamlit as st
import pandas as pd
import altair as alt
import os
import time

# Caminho da logo
logo_path = os.path.join(os.path.dirname(__file__), 'img', 'logo.png')

# Configurações da página
st.set_page_config(
    page_title="Projeto Extensor - Escola da Nuvem",
    page_icon=logo_path if os.path.exists(logo_path) else None,
    layout="wide"
)

# Inicializar o estado da página
if "page" not in st.session_state:
    st.session_state.page = "—"

# Injetar animação CSS uma única vez
def inject_animation_css():
    st.markdown("""
        <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translate3d(0, 20px, 0);
            }
            to {
                opacity: 1;
                transform: translate3d(0, 0, 0);
            }
        }

        .fade-in {
            animation: fadeInUp 1s ease forwards;
            opacity: 0;
        }

        .fade-in-delay-1 { animation-delay: 0.3s; }
        .fade-in-delay-2 { animation-delay: 0.6s; }
        .fade-in-delay-3 { animation-delay: 0.9s; }

        /* Estilizando o elemento stDecoration */
        #stDecoration {
            background-color: #f5f5f5;  /* Altere a cor de fundo */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);  /* Adiciona uma sombra sutil */
        }
        
        /* Outro exemplo de customização */
        .st-emotion-cache-1dp5vir {
            background-image: linear-gradient(90deg, #2569f3, #80d6ff);
        }
        </style>
    """, unsafe_allow_html=True)

# Função para carregar os dados com cache
@st.cache_data
def load_data():
    return pd.read_excel('alunos_pii_none.xlsx')

# Agrupar categorias semelhantes
def group_similar_categories(df):
    similar_groups = {
        'Pós graduação': ['Pós graduação', 'MBA', 'Mestrado', 'Pós-graduação'],
        'Ensino Superior': ['Superior Completo', 'Graduação'],
        'Ensino Médio': ['Ensino Médio Completo'],
        'Ensino Fundamental': ['Ensino Fundamental Completo', 'Fundamental'],
        'Outros': ['Outro', 'Não Especificado']
    }
    for new_category, categories in similar_groups.items():
        df['Escolaridade'] = df['Escolaridade'].replace(categories, new_category)
    return df

# Gráfico de escolaridade
def plot_escolaridade(df):
    st.write("## Distribuição de alunos por nível de escolaridade")
    df = group_similar_categories(df)
    escolaridade_percentual = df['Escolaridade'].value_counts(normalize=True) * 100
    escolaridade_df = escolaridade_percentual.reset_index()
    escolaridade_df.columns = ['Escolaridade', 'Porcentagem']

    chart = alt.Chart(escolaridade_df).mark_bar().encode(
        x=alt.X('Escolaridade:N', sort='-y', title='Nível de Escolaridade'),
        y=alt.Y('Porcentagem:Q', title='Porcentagem (%)'),
        tooltip=[alt.Tooltip('Escolaridade:N', title='Escolaridade'),
                 alt.Tooltip('Porcentagem:Q', format='.2f', title='Porcentagem (%)')]
    ).properties(
        width=600,
        height=400,
    )

    st.altair_chart(chart, use_container_width=True)

    return escolaridade_df

# Página de introdução
def intro():
    inject_animation_css()

    st.markdown('<h1 class="custom-title fade-in fade-in-delay-1">Análise dos dados da Escola da Nuvem</h1>', unsafe_allow_html=True)
    st.markdown('<p class="fade-in fade-in-delay-2">Bem-vindo ao nosso sistema dedicado à análise detalhada dos dados da Escola da Nuvem. Nesta plataforma, você terá acesso a informações valiosas sobre os diversos aspectos das bases de dados da instutição. Nosso principal objetivo é oferecer uma visão clara e profunda das estatísticas e insights que podem ajudar a melhorar as práticas educacionais e direcionar decisões estratégicas para o futuro. Prepare-se para explorar, compreender e interagir com os dados de forma dinâmica e envolvente!</p>', unsafe_allow_html=True)

    # Animação de carregamento de 2 segundos
    with st.spinner("Carregando dados..."):
        time.sleep(2)  # Delay de 2 segundos

    df = load_data()

    with st.expander("📊 Ver preview da distribuição por escolaridade"):
        plot_escolaridade(df)

    st.markdown('<div class="fade-in fade-in-delay-3">', unsafe_allow_html=True)
    if st.button("Ir para a página de Alunos"):
        st.session_state.page = "Alunos"
        st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)

# Página principal de análise dos alunos
def alunos():
    inject_animation_css()

    # Título com animação
    st.markdown('<h1 class="custom-title fade-in fade-in-delay-1">Dados Escola da Nuvem - Alunos</h1>', unsafe_allow_html=True)

    # Texto descritivo com animação
    st.markdown('''<p class="fade-in fade-in-delay-2">
        Esta página apresenta uma análise dos dados dos alunos da Escola da Nuvem. 
        O objetivo é entender o perfil dos estudantes e gerar insights que ajudem a melhorar o impacto da iniciativa.
    </p>''', unsafe_allow_html=True)

    # Carregamento e exibição do gráfico com animação envolvente
    with st.spinner("Carregando dados..."):
        time.sleep(2)  # Delay de 2 segundos

    df = load_data()
    st.markdown('<div class="fade-in fade-in-delay-3">', unsafe_allow_html=True)
    escolaridade_df = plot_escolaridade(df)
    st.markdown('</div>', unsafe_allow_html=True)

    # Disposição em colunas para texto explicativo ao lado da tabela
    col1, col2 = st.columns([2, 3])  # Dividindo em duas colunas: coluna 1 para a tabela e coluna 2 para o texto explicativo
    with col1:
        st.markdown('<span style="font-size: 25px;"><b>Tabela de níveis de distribuição de escolaridade</b></span>', unsafe_allow_html=True)
        st.dataframe(escolaridade_df, width=510)  # Isso controla a altura da tabela
    
    with col2:
        st.markdown('<span style="font-size: 25px;"><b>Análise e Insights</b></span>', unsafe_allow_html=True)
        with st.expander("✅Clique aqui para visualizar os insights", expanded=False):  # O expander inicia fechado    
            st.markdown("""
            - **Ensino Superior Incompleto** (34,82%) é o nível de escolaridade mais comum entre os alunos da Escola da Nuvem. 
            Este dado sugere que a maioria dos estudantes tem alguma experiência universitária, mas não completou o curso. Isso pode indicar a necessidade de apoio para a conclusão de sua formação superior.
            - **Ensino Superior Completo** vem logo após, com 28,21%. Esse índice é relevante para identificar a proporção de alunos com formação completa, o que pode trazer um nível elevado de conhecimentos técnicos e teóricos para a escola.
            - **Ensino Médio Completo** com 21,02% representa uma parcela significativa de alunos. Isso sugere que a Escola da Nuvem tem atraído, além de universitários, jovens e adultos com ensino médio finalizado, possivelmente buscando capacitação adicional.
            - **Pós-graduação** e **Pós-graduação (Mestrado, Doutorado, etc.)** somam 8,72%. Esses números indicam que uma parcela pequena, mas qualificada, tem uma formação avançada, o que pode ser uma vantagem estratégica para a instituição ao trazer essa expertise.
            - **Ensino Fundamental Completo** com 0,61% e **Ensino Técnico** com 0,09% indicam que esses grupos são mais restritos, mas ainda são uma parte importante da diversidade do público atendido.
            - Por fim, é importante notar que a categoria **"Não estou matriculado em nenhuma instituição"** (0,12%) pode sugerir que um pequeno grupo de pessoas não está mais em um contexto educacional formal.

            #### Possíveis Insights:
            1. **Foco em Ensino Superior Incompleto**: Dada a alta porcentagem de alunos com ensino superior incompleto, seria interessante oferecer programas de apoio à conclusão da graduação ou ao desenvolvimento de competências complementares.
            2. **Expandir Programas de Pós-graduação**: Embora a porcentagem de alunos com pós-graduação seja pequena, a presença dessa categoria indica que a escola pode considerar a expansão de programas voltados a este público.
            3. **Apoio ao Ensino Médio Completo**: Com 21,02% dos alunos tendo apenas o ensino médio completo, pode ser interessante oferecer cursos que ajudem a elevar esse público a níveis de educação superior ou técnico.
            4. **Diversificação de Programas**: A presença de alunos com ensino fundamental completo e técnico mostra que a escola atende uma variedade de perfis educacionais, o que poderia ser um ponto de diferenciação, oferecendo cursos especializados.

            Estes insights podem auxiliar na construção de políticas e estratégias educacionais mais direcionadas às necessidades dos alunos da Escola da Nuvem.
            """)

        # Gráfico de linha com média geral
        st.markdown("### 📈 Dispersão do nível de escolaridade em relação à média")

        # Cálculo da média das porcentagens
        media_porcentagem = escolaridade_df['Porcentagem'].mean()

        # Adiciona coluna de classificação (acima ou abaixo da média)
        escolaridade_df['Acima_da_Media'] = escolaridade_df['Porcentagem'] > media_porcentagem

        # Gráfico de linha para representar a evolução dos percentuais de escolaridade
        line_chart = alt.Chart(escolaridade_df).mark_line(point=True).encode(
            x=alt.X('Escolaridade:N', sort='-y', title='Nível de Escolaridade'),
            y=alt.Y('Porcentagem:Q', title='Porcentagem (%)'),
            color=alt.condition(
                alt.datum.Acima_da_Media,
                alt.value('#2ca02c'),  # verde para acima da média
                alt.value('#d62728')   # vermelho para abaixo da média
            ),
            tooltip=[
                alt.Tooltip('Escolaridade:N'),
                alt.Tooltip('Porcentagem:Q', format='.2f'),
            ]
        ).properties(
            width=500,
            height=295,
        )

        # Linha da média
        linha_media = alt.Chart(pd.DataFrame({'y': [media_porcentagem]})).mark_rule(
            color='gray', strokeDash=[5, 5]
        ).encode(y='y:Q')

        # Exibindo o gráfico com a linha da média
        st.altair_chart(line_chart + linha_media, use_container_width=True)

# Mapeamento das páginas
page_names_to_funcs = {
    "—": intro,
    "Alunos": alunos
}

# Sidebar com logo
try:
    if os.path.exists(logo_path):
        st.sidebar.image(logo_path, width=100)
except Exception:
    st.sidebar.warning("Logo não pôde ser carregada.")

st.sidebar.markdown("""
**Bem-vindo ao Projeto Extensor**  
Escolha uma visualização para explorar os dados dos alunos da Escola da Nuvem.
""")

# Selectbox com controle de estado
selected = st.sidebar.selectbox(
    "Escolha uma visualização",
    options=page_names_to_funcs.keys(),
    index=list(page_names_to_funcs.keys()).index(st.session_state.page)
)
if selected != st.session_state.page:
    st.session_state.page = selected
    st.rerun()

# Renderizar página atual
page_names_to_funcs[st.session_state.page]()