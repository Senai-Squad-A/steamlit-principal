import pandas as pd
import numpy as np

df = pd.read_excel("desistencia.xlsx")
df.head()

print(list(df.columns))

print(df["estágio"].head(20))
print(df["estado"].describe())


print(df["motivo_da_desistência"])

## GRAFICO DE DESISTENCIAS POR ESTADO ###

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Supondo que o DataFrame seja chamado df

# 1. Filtrando os dados para casos onde há motivo de desistência
df_desistencia = df[df['motivo_da_desistência'].notna()]

# 2. Agrupar por estado e contar as desistências
desistencias_por_estado = df_desistencia.groupby('estado').size().reset_index(name='contagem')

# 3. Ordenar para pegar os 10 estados com mais desistências
desistencias_por_estado = desistencias_por_estado.sort_values(by='contagem', ascending=False).head(10)

# 4. Plotando o gráfico de barras
plt.figure(figsize=(10, 6))
sns.barplot(x='contagem', y='estado', data=desistencias_por_estado, palette='viridis')

# 5. Ajustes no gráfico
plt.title('Top 10 Estados com Mais Desistências', fontsize=14)
plt.xlabel('Número de Desistências', fontsize=12)
plt.ylabel('Estado', fontsize=12)
plt.tight_layout()

# Exibindo o gráfico
plt.show()

##### MÉDIA DE DESISTENCIA POR ANO #####

import pandas as pd
import matplotlib.pyplot as plt

# Supondo que df já está carregado
df['data_de_desistência_do_curso'] = pd.to_datetime(df['data_de_desistência_do_curso'], errors='coerce')
df['ano'] = df['data_de_desistência_do_curso'].dt.year
df['mes'] = df['data_de_desistência_do_curso'].dt.month

grouped = df.groupby(['ano', 'mes', 'motivo_da_desistência']).size().reset_index(name='quantidade')
monthly_dismissals = grouped.groupby(['ano', 'mes']).agg({'quantidade': 'sum'}).reset_index()
filtered_monthly_dismissals = monthly_dismissals[monthly_dismissals['quantidade'] > 25]

# Corrigir colunas para criação da data
filtered_monthly_dismissals['data'] = pd.to_datetime(
    filtered_monthly_dismissals.rename(columns={'ano': 'year', 'mes': 'month'})[['year', 'month']].assign(day=1)
)

# Criar coluna mes/ano no formato 'Jan/2023'
filtered_monthly_dismissals['mes_ano'] = filtered_monthly_dismissals['data'].dt.strftime('%b/%Y')

# Encontrar os dois maiores picos
top2 = filtered_monthly_dismissals.nlargest(2, 'quantidade')

# Plotar gráfico
plt.figure(figsize=(12,6))
plt.plot(filtered_monthly_dismissals['mes_ano'], filtered_monthly_dismissals['quantidade'],
         marker='o', linestyle='-', color='b', label='Desistências')

# Adicionar marcadores vermelhos e rótulos
for i, row in top2.iterrows():
    plt.plot(row['mes_ano'], row['quantidade'], marker='o', color='red', markersize=10)
    plt.text(row['mes_ano'], row['quantidade'] + 1, str(row['quantidade']),
             color='red', ha='center', fontweight='bold')

plt.xticks(rotation=45)
plt.title('Quantidade de Desistências por Mês/Ano (Ocorrências > 25)')
plt.xlabel('Mês/Ano')
plt.ylabel('Quantidade de Desistências')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()




# Exibindo a média mensal de desistências e os 3 principais motivos de desistência
print(f'Média mensal de desistências: {average_dismissals_per_month:.2f}')
print('Top 3 Motivos de Desistência:')
print(top_3_motivos)

