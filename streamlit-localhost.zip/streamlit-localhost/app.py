import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Configuração da página
st.set_page_config(layout="wide")
st.title("Análise dos Perfis dos Alunos Desistentes")
st.markdown("Exploração interativa dos principais indicadores dos alunos que desistiram.")

# Carregamento dos dados com cache
@st.cache_data
def carregar_dados():
    df = pd.read_excel("perfil_alunos_desistentes_limpo.xlsx")
    return df

df = carregar_dados()

# Padroniza nomes de colunas
df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]

# --- Faixa de Renda com sua lógica personalizada ---
def categorizar_renda(valor):
    try:
        if pd.isna(valor):
            return "Não informado"
        valor = str(valor).replace("R$", "").replace(".", "").replace(",", "").strip()
        valor = int(valor)
        if valor <= 1000:
            return "Até R$1.000"
        elif valor <= 2000:
            return "R$1.001 - R$2.000"
        elif valor <= 4000:
            return "R$2.001 - R$4.000"
        else:
            return "Acima de R$4.000"
    except:
        return "Não informado"

df["faixa_renda_familiar"] = df["renda_familiar_mensal_aproximada"].apply(categorizar_renda)

# --- Estágio ---
df['estágio'] = df['estágio'].fillna('Não informado').astype(str)

# Função padrão de gráfico
def grafico_barras(data, coluna, titulo, xlabel, ylabel):
    plt.figure(figsize=(10, 5))
    ax = sns.countplot(data=data, y=coluna, order=data[coluna].value_counts().index, palette="viridis")
    plt.title(titulo, fontsize=16)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    for p in ax.patches:
        width = p.get_width()
        ax.text(width + 1, p.get_y() + p.get_height() / 2, int(width), va='center')
    st.pyplot(plt.gcf())
    plt.clf()

# Gráficos (sem filtro)
st.subheader("1. Faixa Etária dos Desistentes")
grafico_barras(df, 'faixa_etária', "Distribuição da Faixa Etária", "Quantidade", "Faixa Etária")

st.subheader("2. Situação de Emprego Atual")
grafico_barras(df, 'situação_de_emprego_atual', "Situação de Emprego", "Quantidade", "Situação")

st.subheader("3. Origem dos Alunos")
grafico_barras(df, 'origem', "Origem dos Alunos", "Quantidade", "Origem")

st.subheader("4. Motivo da Desistência")
grafico_barras(df, 'motivo_da_desistência', "Motivo da Desistência", "Quantidade", "Motivo")

st.subheader("5. Faixa de Renda Familiar")
grafico_barras(df, 'faixa_renda_familiar', "Faixa de Renda Familiar", "Quantidade", "Faixa de Renda")