import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

# Função para carregar e processar os dados
def carregar_dados():
    alunos = pd.read_excel('alunos_pii_tratado.xlsx')  # Tabela de alunos
    matricula = pd.read_excel('Matriculas_pii_none.xlsx')  # Tabela de matrícula
    
    # Garantir que as colunas de IDs sejam tratadas como string
    alunos['Id_aluno'] = alunos['Id_aluno'].astype(str)
    matricula['Aluno'] = matricula['Aluno'].astype(str)
    
    # Junção entre as tabelas usando o ID do aluno
    resultado = pd.merge(alunos, matricula, left_on='Id_aluno', right_on='Aluno', how='inner')
    
    # Filtrando os alunos que desistiram (onde 'Motivo da Desistência' não é nulo)
    alunos_desistentes = resultado[resultado['Motivo da Desistência'].notna()]
    
    return alunos_desistentes

# Função para exibir gráficos
def exibir_grafico(df, coluna, titulo, xlabel, ylabel):
    fig, ax = plt.subplots()
    sns.countplot(data=df, x=coluna, ax=ax)
    ax.set_title(titulo)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    st.pyplot(fig)

# Função para exibir distribuição de idade
def exibir_distribuicao_idade(df):
    st.subheader("Distribuição de Idade dos Alunos que Desistiram")
    st.write(df['Idade'].describe())
    st.write("Distribuição de Idade em Faixas Etárias:")
    
    bins = [0, 18, 24, 30, 35, 40, 45, 50, 100]
    labels = ['0-18', '19-24', '25-30', '31-35', '36-40', '41-45', '46-50', '51+']
    df['Faixa Etária'] = pd.cut(df['Idade'], bins=bins, labels=labels, right=False)
    
    exibir_grafico(df, 'Faixa Etária', 'Distribuição de Desistências por Faixa Etária', 'Faixa Etária', 'Número de Alunos')

# Função principal do Streamlit
def main():
    st.title("Análise do Perfil dos Alunos que Desistiram")

    # Carregar os dados
    alunos_desistentes = carregar_dados()
    
    # Exibindo as primeiras linhas do DataFrame
    st.subheader("Exemplo de Alunos que Desistiram")
    st.write(alunos_desistentes.head())

    # Analisando o Motivo da Desistência
    st.subheader("Distribuição de Desistências por Motivo")
    st.write(alunos_desistentes['Motivo da Desistência'].value_counts())
    exibir_grafico(alunos_desistentes, 'Motivo da Desistência', 'Distribuição de Desistências por Motivo', 'Motivo da Desistência', 'Número de Alunos')
    
    # Exibindo a distribuição de idade
    exibir_distribuicao_idade(alunos_desistentes)

    # Analisando a distribuição por sexo (se disponível)
    if 'Sexo' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Sexo")
        st.write(alunos_desistentes['Sexo'].value_counts())
        exibir_grafico(alunos_desistentes, 'Sexo', 'Distribuição de Desistências por Sexo', 'Sexo', 'Número de Alunos')

    # Analisando a distribuição por origem (se disponível)
    if 'Origem' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Origem")
        st.write(alunos_desistentes['Origem'].value_counts())
        exibir_grafico(alunos_desistentes, 'Origem', 'Distribuição de Desistências por Origem', 'Origem', 'Número de Alunos')

    # Analisando a distribuição por tipo de matrícula
    if 'Tipo de Matricula' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Tipo de Matrícula")
        st.write(alunos_desistentes['Tipo de Matricula'].value_counts())
        exibir_grafico(alunos_desistentes, 'Tipo de Matricula', 'Distribuição de Desistências por Tipo de Matrícula', 'Tipo de Matrícula', 'Número de Alunos')

    # Analisando a distribuição por estado
    if 'Estado' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Estado")
        st.write(alunos_desistentes['Estado'].value_counts())
        exibir_grafico(alunos_desistentes, 'Estado', 'Distribuição de Desistências por Estado', 'Estado', 'Número de Alunos')

    # Analisando alunos com baixa frequência (se houver dados de frequência)
    if 'AT - Frequência (%)' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Frequência Baixa")
        alunos_low_freq = alunos_desistentes[alunos_desistentes['AT - Frequência (%)'] < 50]
        st.write(alunos_low_freq['AT - Frequência (%)'].describe())
        exibir_grafico(alunos_low_freq, 'AT - Frequência (%)', 'Distribuição de Desistências por Frequência Baixa', 'Frequência (%)', 'Número de Alunos')

    # Analisando alunos com notas baixas (se houver dados de notas)
    if 'Nota Final' in alunos_desistentes.columns:
        st.subheader("Distribuição de Desistências por Notas Baixas")
        alunos_low_grade = alunos_desistentes[alunos_desistentes['Nota Final'] < 5]
        st.write(alunos_low_grade['Nota Final'].describe())
        exibir_grafico(alunos_low_grade, 'Nota Final', 'Distribuição de Desistências por Notas Baixas', 'Nota Final', 'Número de Alunos')

if __name__ == "__main__":
    main()
