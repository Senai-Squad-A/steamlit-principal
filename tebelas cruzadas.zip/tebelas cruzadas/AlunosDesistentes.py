import pandas as pd

# Lê as planilhas
alunos = pd.read_excel('alunos_tratado_sem_duplicatas.xlsx')
matricula = pd.read_excel('matricula_tratada_sem_duplicatas.xlsx')

# Alinha os campos
alunos["id_aluno"] = alunos["id_aluno"].astype(str).str.strip()
matricula["aluno"] = matricula["aluno"].astype(str).str.strip()

# Filtra os alunos desistentes
desistentes = matricula[matricula["motivo_da_desistência"].notna()]

# Junta com o perfil
desistentes_com_perfil = pd.merge(
    desistentes,
    alunos,
    how="inner",
    left_on="aluno",
    right_on="id_aluno"
)

# Remove colunas totalmente vazias
desistentes_com_perfil.dropna(axis=1, how='all', inplace=True)

# Remove colunas irrelevantes (ajuste a lista conforme necessário)
colunas_irrelevantes = [
    'id', 'hora_de_criação', 'hora_da_modificação', 'criado_por', 'modificado_por',
    'mass_update', 'tag', 'e-mail_secundário', 'opção_de_sair_do_e-mail',
    'hora_da_última_atividade', 'pular_envio_vc2', 'voucher_distribuído',
    'at_-_presença_(aux)', 'pc_-_presença_(aux)', 'id_aluno'
]

# Remove apenas se existirem no DataFrame (evita erro)
colunas_para_remover = [col for col in colunas_irrelevantes if col in desistentes_com_perfil.columns]
desistentes_com_perfil.drop(columns=colunas_para_remover, inplace=True)

# Ver resultado
print(desistentes_com_perfil.head())

# Salva para análise
desistentes_com_perfil.to_excel("perfil_alunos_desistentes_limpo.xlsx", index=False)
