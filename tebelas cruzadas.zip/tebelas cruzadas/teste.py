import pandas as pd


alunos = pd.read_excel('alunos_pii_tratado.xlsx')

print(alunos.__len__())
